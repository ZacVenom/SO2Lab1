package drawingTool;

import java.awt.Color;
import java.awt.Graphics;

public class Hair {
	
	Graphics pen;
	
	public void drawAt(int left, int bottom) {
		pen = Monkey.pen();
		pen.setColor(Color.decode("#964B00"));
		for(int i = 0; i < 30; i++) {
			pen.drawString("|||||||||||||||||||||||||||||||||||||||", left+20, bottom+10+i);
			pen.drawString("-------------------------", left+30, bottom+i);
		}
	}
}
