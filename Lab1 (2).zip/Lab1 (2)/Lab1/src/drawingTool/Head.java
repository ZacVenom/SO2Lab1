package drawingTool;

import java.awt.Color;
import java.awt.Graphics;

public class Head {
	Graphics pen;
	private int width;
	private int height;
	
	public Head(int width, int height) {
		this.width = width;
		this.height = height;
	}
	public void drawAt(int left, int bottom) {
		pen = Monkey.pen();
		pen.fillOval(left-50, bottom+30, width-70, height-70);
		pen.fillOval(left+120, bottom+30, width-70, height-70);
		pen.setColor(Color.decode("#c2af7c"));
		pen.fillOval(left-35, bottom+40, width-90, height-90);
		pen.fillOval(left+125, bottom+40, width-90, height-90);
		pen.setColor(Color.decode("#964B00"));
		pen.fillOval(left, bottom, width, height);
		Face face = new Face();
		face.drawAt(left, bottom);
		Hair hair = new Hair();
		hair.drawAt(left, bottom);
	}

}
