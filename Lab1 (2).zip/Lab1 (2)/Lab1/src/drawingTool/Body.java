package drawingTool;

import java.awt.Color;
import java.awt.Graphics;

public class Body{

	private Graphics pen;
	private int width;
	private int height;
	public Body(int width, int height) {
		this.width = width;
		this.height = height;
	}
	public void drawAt(int left, int bottom) {
		pen = Monkey.pen();
		pen.fillOval(left, bottom, width, height);
		pen.setColor(Color.decode("#c2af7c"));
		pen.fillOval(left+25, bottom+35, width-70, height-70);
		pen.setColor(Color.decode("#964B00"));
		Leg leftLeg = new Leg(50,200);
		leftLeg.drawAt(left, bottom+250);
		Leg rightLeg = new Leg(50,200);
		rightLeg.drawAt(left+150, bottom+250);
		Tail tail = new Tail(320,320);
		tail.drawAt(left+10, bottom-90);
		Head head = new Head(150,150);
		head.drawAt(left+25,bottom-150);
		Hand rightHand = new Hand(230,40);
		rightHand.drawAt(left+160, bottom+20);
		Hand leftHand = new Hand(230,40);
		leftHand.drawAt(left-190, bottom+20);
	}

}
