package drawingTool;

import java.awt.Graphics;

public class Face {
	Graphics pen;

	public void drawAt(int left, int bottom) {
		pen = Monkey.pen();
		Eye rightEye = new Eye(20,35);
		rightEye.drawAt(left+100, bottom+50);
		Eye leftEye = new Eye(20,35);
		leftEye.drawAt(left+30, bottom+50);
		Mouth mouth = new Mouth(70,55);
		mouth.drawAt(left+40, bottom+85);
		
	}
}
