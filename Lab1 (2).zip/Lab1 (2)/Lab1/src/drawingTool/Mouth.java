package drawingTool;

import java.awt.Color;
import java.awt.Graphics;

public class Mouth {
	Graphics pen;
	private int width;
	private int height;
	public Mouth(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	public void drawAt(int left, int bottom) {
		pen = Monkey.pen();
		pen.setColor(Color.decode("#c2af7c"));
		pen.fillOval(left, bottom, width, height);
		pen.setColor(Color.decode("#11111"));
		pen.fillOval(left+10, bottom+20, 20, 15);
		pen.setColor(Color.decode("#964B00"));

	}
}
