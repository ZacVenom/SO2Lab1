package drawingTool;

import java.awt.Graphics;

public class Hand {
	Graphics pen;
	private int width;
	private int height;
	public Hand(int width, int height) {
		this.width = width;
		this.height = height;
	}
	public void drawAt(int left, int bottom) {
		pen = Monkey.pen();
		pen.fillOval(left, bottom, width, height);
	}
	
}
