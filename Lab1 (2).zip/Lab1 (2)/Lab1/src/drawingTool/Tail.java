package drawingTool;

import java.awt.Graphics;

public class Tail {
	private Graphics pen;
	private int width;
	private int height;
	
	public Tail(int width, int height) {
		this.width = width;
		this.height = height;
	}
	public void drawAt(int left, int bottom) {
		pen = Monkey.pen();
		
		for(int i = 0; i<20; i++) {
			pen.drawArc(left, bottom+i, width, height, 270, 85);
		}
	}
}
