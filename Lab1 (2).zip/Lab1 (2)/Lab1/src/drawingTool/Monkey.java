package drawingTool;

import java.awt.Graphics;

public class Monkey {
	public static Graphics pen;
	public Monkey(Graphics pen) {
		Monkey.pen = pen;
	}
	public void drawAt(int left, int bottom) {
		Body body = new Body(200,300);
		body.drawAt(left,bottom);
	}
	public static Graphics pen() {
		return Monkey.pen;
	}
}
