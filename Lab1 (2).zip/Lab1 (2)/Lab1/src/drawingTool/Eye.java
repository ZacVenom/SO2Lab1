package drawingTool;

import java.awt.Color;
import java.awt.Graphics;

public class Eye {
	Graphics pen;
	private int width;
	private int height;
	public Eye(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	public void drawAt(int left, int bottom) {
		pen = Monkey.pen();
		pen.setColor(Color.decode("#111111"));
		pen.fillOval(left, bottom, width, height);
		pen.setColor(Color.decode("#964B00"));
	}
	
}
